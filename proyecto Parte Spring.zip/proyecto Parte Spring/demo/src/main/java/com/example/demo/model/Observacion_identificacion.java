package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Observacion_identificacion")
public class Observacion_identificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "ID_Observacion")
    private Observacion observacion;

    @ManyToOne
    @JoinColumn(name = "ID_Identificacion")
    private identificacion identificacion;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Observacion getObservacion() {
        return observacion;
    }

    public void setObservacion(Observacion observacion) {
        this.observacion = observacion;
    }

    public identificacion getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(identificacion identificacion) {
        this.identificacion = identificacion;
    }
}