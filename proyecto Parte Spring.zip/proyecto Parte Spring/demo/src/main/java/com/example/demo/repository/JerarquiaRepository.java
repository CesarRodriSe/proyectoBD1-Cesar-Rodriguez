package com.example.demo.repository;

import com.example.demo.model.jerarquia_taxon;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface JerarquiaRepository extends JpaRepository<jerarquia_taxon, Long> {
}
