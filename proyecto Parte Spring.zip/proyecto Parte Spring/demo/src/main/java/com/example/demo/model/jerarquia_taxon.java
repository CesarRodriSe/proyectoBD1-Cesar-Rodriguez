package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "jerarquia_taxon")
public class jerarquia_taxon {
        @Id
    @Column(name = "Nivel")
    private Long Nivel;

    @Column(name = "Tipo_Jerarquia")
    private String TipoJerarquia;

    // Getters
    public Long getNivel() {return Nivel;}
    
    public String getTipoJerarquia() {return TipoJerarquia;}
}
