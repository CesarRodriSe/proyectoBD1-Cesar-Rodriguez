package com.example.demo.controller;

import com.example.demo.model.*;
import com.example.demo.service.*;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@Controller
public class IdentificacionController {

    @Autowired
    private IdentificacionService identificacionService;

    @Autowired
    private ObservacionService observacionService;

    @Autowired
    private ObservacionIdentificacionService observacionIdentificacionService;

    @PostMapping("/agregar-identificacion/{idObservacion}")
public String agregarIdentificacion(@PathVariable Long idObservacion, HttpSession session) {
    Usuario usuarioActual = (Usuario) session.getAttribute("usuarioActual");
    if (usuarioActual == null) {
        return "redirect:/seleccionar-usuario"; 
    }

    Observacion observacion = observacionService.obtenerPorId(idObservacion);
    if (observacion == null) {
        throw new RuntimeException("La observación no existe");
    }

    
    identificacion nuevaIdentificacion = new identificacion();
    nuevaIdentificacion.setFechaIdentificacion(LocalDate.now());
    nuevaIdentificacion.setTaxon(observacion.getTaxon());
    nuevaIdentificacion.setUsuario(usuarioActual); 
    identificacionService.save(nuevaIdentificacion);

    
    Observacion_identificacion relacion = new Observacion_identificacion();
    relacion.setObservacion(observacion);
    relacion.setIdentificacion(nuevaIdentificacion);
    observacionIdentificacionService.guardar(relacion);

    return "redirect:/";
}

}

