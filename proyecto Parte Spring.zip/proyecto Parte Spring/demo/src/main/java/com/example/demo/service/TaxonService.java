package com.example.demo.service;

import com.example.demo.model.Taxon;
import com.example.demo.repository.TaxonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TaxonService {

    @Autowired
    private TaxonRepository taxonRepository;

    public List<Taxon> obtenerTodos() {
        return taxonRepository.findAll();
    }

    public Taxon obtenerPorId(Long id) {
        return taxonRepository.findById(id).orElse(null);
    }

    public List<Taxon> obtenerHijos(Long idPadre) {
        return taxonRepository.findByTaxonPadreIdTaxon(idPadre);
    }

    public List<Taxon> obtenerTaxonesRaiz() {
        return taxonRepository.findByTaxonPadreIsNull();
    }

}
