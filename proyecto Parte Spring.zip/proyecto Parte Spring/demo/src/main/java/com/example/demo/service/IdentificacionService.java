package com.example.demo.service;

import com.example.demo.model.identificacion;
import com.example.demo.repository.IdentificacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;





@Service
public class IdentificacionService {

    @Autowired
    private IdentificacionRepository identificacionRepository;

    public List<identificacion> findAll() {
        return identificacionRepository.findAll();
    }

    public Optional<identificacion> findById(Long id) {
        return identificacionRepository.findById(id);
    }

    public identificacion save(identificacion identificacion) {
        return identificacionRepository.save(identificacion);
    }

    public void deleteById(Long id) {
        identificacionRepository.deleteById(id);
    }
}