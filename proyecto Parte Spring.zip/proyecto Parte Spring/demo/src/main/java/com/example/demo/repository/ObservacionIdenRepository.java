package com.example.demo.repository;

import com.example.demo.model.Observacion_identificacion;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;



@Repository
public interface ObservacionIdenRepository extends JpaRepository<Observacion_identificacion, Long> {
    @Query("SELECT COUNT(o) FROM Observacion_identificacion o WHERE o.observacion.idObservacion = :idObservacion")
    int contarPorIdObservacion(Long idObservacion);


}