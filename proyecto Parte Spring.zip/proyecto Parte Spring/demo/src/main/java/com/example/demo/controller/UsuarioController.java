package com.example.demo.controller;

import com.example.demo.model.Usuario;
import com.example.demo.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;
import java.util.List;

@Controller
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/seleccionar-usuario")
    public String mostrarUsuarios(Model model) {
        List<Usuario> usuarios = usuarioService.obtenerTodos();
        model.addAttribute("usuarios", usuarios);
        return "seleccionar-usuario";
    }

    @PostMapping("/seleccionar-usuario")
public String seleccionarUsuario(@RequestParam Integer cedula, HttpSession session) {
    Usuario usuario = usuarioService.obtenerPorId(cedula);
    if (usuario != null) {
        session.setAttribute("usuarioActual", usuario); // Guardar el usuario en la sesión
    }
    return "redirect:/"; // Redirige a la pantalla de bienvenida
}

    @GetMapping("/cerrar-sesion")
    public String cerrarSesion(HttpSession session) {
        session.invalidate(); // Elimina la sesión actual
        return "redirect:/seleccionar-usuario"; // Redirige a la pantalla de selección de usuario
    }
}
