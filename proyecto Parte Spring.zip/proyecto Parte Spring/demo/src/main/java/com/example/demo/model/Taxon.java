package com.example.demo.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "Taxon")
public class Taxon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idTaxon;

    @Column(name = "Nombre_Comun")
    private String nombreComun;

    @Column(name = "Nombre_Cientifico")
    private String nombreEspecie;

    @ManyToOne
    @JoinColumn(name = "Nivel")
    private jerarquia_taxon nivel;

    @ManyToOne
    @JoinColumn(name = "ID_Padre")
    private Taxon taxonPadre;

    @OneToMany(mappedBy = "taxonPadre", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Taxon> hijos; 

    // Getters y Setters
    public Long getIdTaxon() {
        return idTaxon;
    }

    public void setIdTaxon(Long idTaxon) {
        this.idTaxon = idTaxon;
    }

    public String getNombreComun() {
        return nombreComun;
    }

    public void setNombreComun(String nombreComun) {
        this.nombreComun = nombreComun;
    }

    public String getNombreEspecie() {
        return nombreEspecie;
    }

    public void setNombreEspecie(String nombreEspecie) {
        this.nombreEspecie = nombreEspecie;
    }

    public jerarquia_taxon getNivel() {
        return nivel;
    }

    public void setNivel(jerarquia_taxon nivel) {
        this.nivel = nivel;
    }

    public Taxon getTaxonPadre() {
        return taxonPadre;
    }

    public void setTaxonPadre(Taxon taxonPadre) {
        this.taxonPadre = taxonPadre;
    }

    public List<Taxon> getHijos() {
        return hijos;
    }

    public void setHijos(List<Taxon> hijos) {
        this.hijos = hijos;
    }

    public String getJerarquia() {
        StringBuilder jerarquia = new StringBuilder(nombreComun + "=" + nombreEspecie);
        Taxon actual = this.taxonPadre;
    
        while (actual != null) {
            jerarquia.insert(0, actual.nombreEspecie + "/");
            actual = actual.getTaxonPadre();
        }
    
        return jerarquia.toString();
    }
}