package com.example.demo.service;
import org.springframework.stereotype.Service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.demo.model.Imagen;
import com.example.demo.repository.ImagenRepository;



@Service
public class ImagenService {

    @Autowired
    private ImagenRepository imagenRepository;

    public List<Imagen> obtenerTodas() {
        return imagenRepository.findAll();
    }

    public Imagen obtenerPorId(Long id) {
        return imagenRepository.findById(id).orElse(null);
    }

    public Imagen guardar(Imagen imagen) {
        try {
            
            return imagenRepository.save(imagen);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }



public boolean eliminar(Long id) {
    if (imagenRepository.existsById(id)) {
        imagenRepository.deleteById(id);
        return true;
    }
    return false;
}

}
