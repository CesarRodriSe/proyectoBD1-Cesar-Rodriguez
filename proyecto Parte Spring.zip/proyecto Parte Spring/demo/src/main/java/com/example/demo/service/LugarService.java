package com.example.demo.service;

import com.example.demo.model.Lugar;
import com.example.demo.repository.LugarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;





@Service
public class LugarService {

    @Autowired
    private LugarRepository lugarRepository;

    public List<Lugar> findAll() {
        return lugarRepository.findAll();
    }

    public Optional<Lugar> findById(Long id) {
        return lugarRepository.findById(id);
    }

    public Lugar save(Lugar lugar) {
        return lugarRepository.save(lugar);
    }

    public void deleteById(Long id) {
        lugarRepository.deleteById(id);
    }
}
