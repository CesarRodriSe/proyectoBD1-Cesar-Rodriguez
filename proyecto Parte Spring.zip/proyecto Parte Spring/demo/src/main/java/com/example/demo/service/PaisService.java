package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

import com.example.demo.model.Pais;
import com.example.demo.repository.PaisRepository;
@Service
public class PaisService {

    @Autowired
    private PaisRepository paisRepository;

    public List<Pais> obtenerTodos() {
        return paisRepository.findAll();
    }

    public Pais obtenerPorId(Long id) {
        return paisRepository.findById(id).orElse(null);
    }
}

