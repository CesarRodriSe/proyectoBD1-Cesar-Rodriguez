package com.example.demo.controller;

import com.example.demo.model.*;
import com.example.demo.service.*;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;



@Controller
public class ObservacionController {

    @Autowired
    private TaxonService taxonService;

    @Autowired
    private LugarService lugarService;

    @Autowired
    private ImagenService imagenService;

    @Autowired
    private ObservacionService observacionService;


    @GetMapping("/agregar-observacion")
    public String mostrarFormularioAgregar(Model model) 
    {
        model.addAttribute("taxones", taxonService.obtenerTodos());
        return "agregar-observacion";
    }

    @PostMapping("/agregar-observacion")
public String agregarObservacion(
        @RequestParam String latitud,
        @RequestParam String longitud,
        @RequestParam String url,
        @RequestParam String permisos,
        @RequestParam Long taxon,
        @RequestParam String comentario,
        @RequestParam String duenno,
        HttpSession session) {

    
    Usuario usuarioActual = (Usuario) session.getAttribute("usuarioActual");
    if (usuarioActual == null) {
        return "redirect:/seleccionar-usuario";
    }

    // Crear y guardar el lugar
    Lugar lugar = new Lugar();
    lugar.setLatitud(new BigDecimal(latitud));
    lugar.setLongitud(new BigDecimal(longitud));
    lugar = lugarService.save(lugar);

    // Crear y guardar la imagen
    Imagen imagen = new Imagen();
    imagen.setUrl(url);
    imagen.setFechaFoto(LocalDate.now());
    imagen.setPermisosImagen(permisos);
    imagen.setLugar(lugar);
    imagen.setTaxon(taxonService.obtenerPorId(taxon));
    imagen.setDuenno(duenno);
    imagen.setUsuarioFotografo(usuarioActual);
    imagen = imagenService.guardar(imagen);

    if (imagen == null || imagen.getIdImagen() == null) {
        throw new RuntimeException("Error al guardar la imagen");
    }

    
    Observacion observacion = new Observacion();
    observacion.setFechaObservacion(LocalDate.now());
    observacion.setLugar(lugar);
    observacion.setImagen(imagen); 
    observacion.setTaxon(taxonService.obtenerPorId(taxon));
    observacion.setComentario(comentario);
    observacion.setUsuario(usuarioActual);
    observacionService.crear(observacion);

    return "redirect:/";
}
}