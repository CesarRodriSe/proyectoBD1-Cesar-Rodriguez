package com.example.demo.service;

import com.example.demo.model.Observacion;
import com.example.demo.repository.ObservacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class ObservacionService {

    @Autowired 
    private ObservacionRepository observacionRepository;

   
    public List<Observacion> obtenerTodas() {
        return observacionRepository.findAll();
    }

    
    public Observacion crear(Observacion observacion) {
        return observacionRepository.save(observacion); 
    }

    
    public Observacion obtenerPorId(Long id) {
        return observacionRepository.findById(id).orElse(null); 
    }

    
    public Observacion actualizar(Observacion observacion) {
        return observacionRepository.save(observacion);
    }

    
    public void eliminar(Long id) {
        observacionRepository.deleteById(id);
    }
}
