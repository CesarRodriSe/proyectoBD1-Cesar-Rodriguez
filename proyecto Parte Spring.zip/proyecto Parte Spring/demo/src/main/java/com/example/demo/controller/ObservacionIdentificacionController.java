package com.example.demo.controller;

import com.example.demo.model.Observacion;

import com.example.demo.model.Usuario;
import com.example.demo.service.ObservacionService;

import com.example.demo.service.ObservacionIdentificacionService;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class ObservacionIdentificacionController {

    @Autowired
    private ObservacionService observacionService;

    @Autowired
    private ObservacionIdentificacionService observacionIdentificacionService;


    @GetMapping("/")
public String mostrarBienvenida(Model model, HttpSession session) {
    
    Usuario usuarioActual = (Usuario) session.getAttribute("usuarioActual");
    if (usuarioActual == null) {
        return "redirect:/seleccionar-usuario"; 
    }

    
    List<Observacion> observaciones = observacionService.obtenerTodas();

    
    Map<Long, Integer> conteoIdentificaciones = new HashMap<>();
    for (Observacion observacion : observaciones) {
        Long idObservacion = observacion.getIdObservacion();
        int conteo = observacionIdentificacionService.contarIdentificacionesPorObservacion(idObservacion);
        conteoIdentificaciones.put(idObservacion, conteo);
    }

    // Agregar datos al modelo
    model.addAttribute("usuarioActual", usuarioActual); // Agregar el usuario actual
    model.addAttribute("observaciones", observaciones);
    model.addAttribute("conteoIdentificaciones", conteoIdentificaciones);

    return "bienvenida";
}

}
