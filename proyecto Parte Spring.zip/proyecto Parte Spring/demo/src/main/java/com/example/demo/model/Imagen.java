package com.example.demo.model;

import java.time.LocalDate;
import jakarta.persistence.*;

@Entity
@Table(name = "Imagen")
public class Imagen {

    // ID
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_Imagen")
    private Long idImagen;

    // Datos
    @Column(name = "Fecha_Foto", nullable = false)
    private LocalDate fechaFoto;

    @Column(name = "permisos", nullable = false)
    private String permisosImagen;

    @Column(name = "url", nullable = false)
    private String url;

    @Column(name = "Dueño", nullable = false)
    private String duenno;

    // Foreign keys
    @ManyToOne
    @JoinColumn(name = "Usuario_Fotografo")
    private Usuario usuarioFotografo;

    @ManyToOne
    @JoinColumn(name = "ID_Lugar")
    private Lugar lugar;

    @ManyToOne
    @JoinColumn(name = "ID_Taxon")
    private Taxon taxon;

    // Getters y Setters
    public Long getIdImagen() {
        return idImagen;
    }

    public void setIdImagen(Long idImagen) {
        this.idImagen = idImagen;
    }

    public LocalDate getFechaFoto() {
        return fechaFoto;
    }

    public void setFechaFoto(LocalDate fechaFoto) {
        this.fechaFoto = fechaFoto;
    }

    public String getPermisosImagen() {
        return permisosImagen;
    }

    public void setPermisosImagen(String permisosImagen) {
        this.permisosImagen = permisosImagen;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDuenno() {
        return duenno;
    }

    public void setDuenno(String duenno) {
        this.duenno = duenno;
    }

    public Usuario getUsuarioFotografo() {
        return usuarioFotografo;
    }

    public void setUsuarioFotografo(Usuario usuarioFotografo) {
        this.usuarioFotografo = usuarioFotografo;
    }

    public Lugar getLugar() {
        return lugar;
    }

    public void setLugar(Lugar lugar) {
        this.lugar = lugar;
    }

    public Taxon getTaxon() {
        return taxon;
    }

    public void setTaxon(Taxon taxon) {
        this.taxon = taxon;
    }
}
