package com.example.demo.service;
import org.springframework.stereotype.Service;
import java.util.List;
import com.example.demo.model.Observacion_identificacion;
import com.example.demo.repository.ObservacionIdenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Optional;





@Service
public class ObservacionIdentificacionService {

    @Autowired
    private ObservacionIdenRepository ObservacionIdenRepository;

    public List<Observacion_identificacion> obtenerObservacionesConIdentificaciones() {
        return ObservacionIdenRepository.findAll();
    }

    public Optional<Observacion_identificacion> findById(Long id) {
        return ObservacionIdenRepository.findById(id);
    }

    public Observacion_identificacion guardar(Observacion_identificacion observacionIdentificacion) {
        return ObservacionIdenRepository.save(observacionIdentificacion);
    }

    public void deleteById(Long id) {
        ObservacionIdenRepository.deleteById(id);
    }

    public int contarIdentificacionesPorObservacion(Long idObservacion) {
        return ObservacionIdenRepository.contarPorIdObservacion(idObservacion);
    }
}