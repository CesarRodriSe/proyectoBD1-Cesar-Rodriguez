package com.example.demo.service;
import org.springframework.stereotype.Service;
import java.util.List;
import com.example.demo.model.jerarquia_taxon;
import com.example.demo.repository.JerarquiaRepository;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class JerarquiaService {

    @Autowired
    private JerarquiaRepository jerarquiaRepository;

    public List<jerarquia_taxon> obtenerTodas() {
        return jerarquiaRepository.findAll();
    }

    public jerarquia_taxon obtenerPorId(Long id) {
        return jerarquiaRepository.findById(id).orElse(null);
    }
}

