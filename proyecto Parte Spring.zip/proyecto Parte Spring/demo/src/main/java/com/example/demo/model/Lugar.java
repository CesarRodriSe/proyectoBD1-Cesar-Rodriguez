package com.example.demo.model;

import jakarta.persistence.*;
import java.math.BigDecimal;


@Entity
@Table(name = "Lugar")
public class Lugar {
        @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idLugar;
    
    @Column(name = "Latitud")
    private BigDecimal latitud;

    @Column(name = "Longitud")
    private BigDecimal longitud;

    // Getters y Setters
    public Long getIdLugar() { return idLugar; }
    public void setObservacion(Long IdLugar) { this.idLugar = IdLugar; }

    public BigDecimal getLatitud() { return latitud; }
    public void setLatitud(BigDecimal Latitud) { this.latitud = Latitud; }

    public BigDecimal getLongitud() {
        return longitud;
    }
    public void setLongitud(BigDecimal longitud) {
        this.longitud = longitud;
    }
}
