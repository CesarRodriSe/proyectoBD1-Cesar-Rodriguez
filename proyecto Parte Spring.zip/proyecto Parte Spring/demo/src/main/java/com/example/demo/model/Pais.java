package com.example.demo.model;


import jakarta.persistence.*;

@Entity
@Table(name = "Pais")
public class Pais {
        @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPais;

    @Column(name = "Nombre_Pais")
    private String NombrePais;
    
    // Getters y Setters
    public Long getIdPais() { return idPais; }
    public void setIdPais(Long idPais) { this.idPais = idPais; }

    public String getNombrePais() { return NombrePais; }
    public void setNombrePais(String NombrePais) { this.NombrePais = NombrePais; }
}