package com.example.demo.model;

import java.time.LocalDate;
import jakarta.persistence.*;

@Entity
@Table(name = "identificacion")
public class identificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_identificacion") 
    private long idIdentificacion;

    @Column(name = "Fecha_Identificacion")
    private LocalDate fechaIdentificacion;

    @ManyToOne
    @JoinColumn(name = "ID_Taxon")
    private Taxon taxon;

    @ManyToOne
    @JoinColumn(name = "ID_Usuario")
    private Usuario usuario;

    // Getters y Setters
    public long getIdIdentificacion() { return idIdentificacion; }
    public void setIdIdentificacion(long idIdentificacion) { this.idIdentificacion = idIdentificacion; }

    public LocalDate getFechaIdentificacion() { return fechaIdentificacion; }
    public void setFechaIdentificacion(LocalDate fechaIdentificacion) { this.fechaIdentificacion = fechaIdentificacion; }

    public Taxon getTaxon() { return taxon; }
    public void setTaxon(Taxon taxon) { this.taxon = taxon; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
}

